﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace First_10_NaturalReverseOrder
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=10, num;

            //Read a number from user
            //Console.Write("Enter number: ");
            //num = Convert.ToInt32(Console.ReadLine());

            ///*Running loop from the number entered by user,
              //and Decrementing by 1*/
            for (i = 10; i >= 1; i--)
            {
                Console.WriteLine("\n" + i);
            }

            Console.ReadLine();





        }
    }
}
