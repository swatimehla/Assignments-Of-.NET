﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assignment_1._2
{
    class Program
    {
        static void Main(string[] args)
        { 
        string strFirst;
        char charCout;
        int Count = 0;
        Console.Write("Enter Your String:");  
        strFirst = Console.ReadLine();  
        Console.Write("Enter Count Character:");  
        charCout = Convert.ToChar(Console.ReadLine());  
        Console.Write("Your Character Count:");  
        foreach(char chr in strFirst) {  
            if (chr == charCout) {  
                Count++;  
            }
}
Console.WriteLine(Count);  
                 
            }
        }
    }
  
