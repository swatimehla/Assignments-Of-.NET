﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diamond_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int i,j, n = 5;
            for(i=n;i>=1;i--)
            {
                for(j=1;j<=i-1;j++)
                {
                    Console.Write("\t");
                }
                for (j = i; j <= n; j++)
                {
                    Console.Write(j);
                    Console.Write("\t");
                }
                for(j=n-1;j>=i;j--)
                {
                    Console.Write(j);
                    Console.Write("\t");
                }
                //for(j=1;j<=n-i;j++)
                //{
                //    Console.Write("\t");
                //}
                Console.Write("\n");
            }
            Console.ReadKey();
        }
    }
}
