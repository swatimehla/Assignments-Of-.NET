﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_Csharp_5th
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("\nEnter value of n : ");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n");
            for(int i=1;i<=n;i++)
            {
                Console.Write(i * i * i);
                Console.Write("\t");
            }
            Console.ReadKey();
        }
    }
}
